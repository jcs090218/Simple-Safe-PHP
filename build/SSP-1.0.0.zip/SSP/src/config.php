<?php
/**
 * $File: config.php $
 * $Date: 2017-11-14 17:37:54 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2017 by Shen, Jen-Chieh $
 */

namespace SSP;


$sspLogColor = 'black';
$sspErrorColor = 'red';
$sspWarningColor = '#Ffd700';

?>

<?php
/**
 * $File: sspl.php $
 * $Date: 2017-10-09 14:43:47 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2017 by Shen, Jen-Chieh $
 */

namespace SSP;

/* Include all the files here... */


include_once("src/config.php");
include_once("src/util.php");
include_once("src/sql.php");
include_once("src/debug.php");

?>
